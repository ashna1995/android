package com.ashna.team3_mapd711_project_milestone2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase

    // UI Elements
    private lateinit var userNameOrEmailLayout: TextInputLayout
    private lateinit var passwordLayout: TextInputLayout
    private lateinit var loginButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var welcomeTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize Room Database with lifecycleScope
        db = AppDatabase.getDatabase(this, lifecycleScope)

        // Initialize UI Elements
        userNameOrEmailLayout = findViewById(R.id.userNameOrEmailLayout)
        passwordLayout = findViewById(R.id.passwordLayout)
        loginButton = findViewById(R.id.loginButton)
        progressBar = findViewById(R.id.progressBar)
        welcomeTextView = findViewById(R.id.welcomeTextView)

        // Check if user is already logged in
        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val savedUserName = sharedPref.getString("USER_NAME", null)
        if (savedUserName != null) {
            showWelcomeMessage(savedUserName)
        }

        // Login Button Click Listener
        loginButton.setOnClickListener {
            loginUser()
        }
    }
    private fun loginUser() {
        val userNameOrEmail = userNameOrEmailLayout.editText?.text.toString().trim()
        val password = passwordLayout.editText?.text.toString().trim()

        if (userNameOrEmail.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        progressBar.visibility = View.VISIBLE
        loginButton.isEnabled = false

        lifecycleScope.launch(Dispatchers.IO) {
            val customer = db.customerDao().loginWithEmailOrUsername(userNameOrEmail, password)
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                loginButton.isEnabled = true

                if (customer != null) {
                    // Save user name in SharedPreferences
                    val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
                    with(sharedPref.edit()) {
                        putString("USER_NAME", customer.userName)
                        apply()
                    }

                    showWelcomeMessage(customer.userName)
                    Toast.makeText(this@LoginActivity, "Login Successful", Toast.LENGTH_SHORT).show()

                    // Delay the transition to give time for the welcome message to be seen
                    lifecycleScope.launch {
                        kotlinx.coroutines.delay(2000) // 2 seconds delay
                        val intent = Intent(this@LoginActivity, PhoneBrandActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                } else {
                    Toast.makeText(this@LoginActivity, "Invalid Credentials", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showWelcomeMessage(userName: String) {
        welcomeTextView.text = "Welcome, $userName!"
        welcomeTextView.visibility = View.VISIBLE
    }
}