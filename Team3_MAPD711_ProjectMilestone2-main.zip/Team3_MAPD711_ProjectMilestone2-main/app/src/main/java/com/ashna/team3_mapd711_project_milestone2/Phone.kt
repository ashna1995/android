package com.ashna.team3_mapd711_project_milestone2

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "phones")
data class Phone(
    @PrimaryKey val productId: Int,
    @ColumnInfo(name = "brand") val phoneMake: String,
    @ColumnInfo(name = "model") val phoneModel: String,
    @ColumnInfo(name = "color") val phoneColor: String,
    @ColumnInfo(name = "storage") val storageCapacity: String, // Comma-separated values
    @ColumnInfo(name = "price") val price: Double,
    @ColumnInfo(name = "stock") val stock: Int
)