package com.ashna.team3_mapd711_project_milestone2

import androidx.lifecycle.LiveData
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.*

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val orderId: Int = 0,
    @ColumnInfo(name = "product_id") val productId: Int,
    @ColumnInfo(name = "customer_id") val customerId: Int,
    @ColumnInfo(name = "status") val status: String = "Ordered",
    @ColumnInfo(name = "total_amount") val totalAmount: Double,
    @ColumnInfo(name = "order_date") val orderDate: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "brand") val brand: String,
    @ColumnInfo(name = "model") val model: String,
    @ColumnInfo(name = "storage") val storage: String,
    @ColumnInfo(name = "color") val color: String
)