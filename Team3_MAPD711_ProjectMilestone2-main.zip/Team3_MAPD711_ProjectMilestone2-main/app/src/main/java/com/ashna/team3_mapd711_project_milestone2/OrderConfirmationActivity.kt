package com.ashna.team3_mapd711_project_milestone2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

/***
CenPhone Mobile Shopping App
 *
 * By Team 3
 * Ashna Paul (301479554)
 * Aarya Savaliya (301473601)
 * Aditya Janjanam (301357523)
 *
 * Course Name: Samsung Android Application Development
 * Course Code: MAPD 711
 *
 * ***/

class OrderConfirmationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_confirmation)

        val brand = intent.getStringExtra("brand") ?: "Unknown Brand"
        val model = intent.getStringExtra("model") ?: "Unknown Model"
        val price = intent.getStringExtra("price") ?: "N/A"
        val storage = intent.getStringExtra("storage") ?: "N/A"
        val color = intent.getStringExtra("color") ?: "N/A"
        val fullName = intent.getStringExtra("fullName") ?: "N/A"
        val street = intent.getStringExtra("street") ?: "N/A"
        val city = intent.getStringExtra("city") ?: "N/A"
        val postalCode = intent.getStringExtra("postalCode") ?: "N/A"
        val paymentMethod = intent.getStringExtra("paymentMethod") ?: "N/A"
        val deliveryMethod = intent.getStringExtra("deliveryMethod") ?: "N/A"
        val location = intent.getStringExtra("location") ?: "N/A"

        val orderNumber = generateOrderNumber()
        val timestamp = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())

        findViewById<TextView>(R.id.orderDetailsTextView).text = "Order #$orderNumber details"

        val orderSummaryTextView: TextView = findViewById(R.id.orderSummaryTextView)
        orderSummaryTextView.text = """
            Phone: $brand $model
            Price: $price
            Storage: $storage
            Color: $color
            
            Customer: $fullName
            ${if (deliveryMethod == "Door Delivery") "Delivery Address:" else "Pickup Location:"}
            ${if (deliveryMethod == "Door Delivery") "\n$street\n$city,\n$postalCode" else location}
            
            Payment Method: $paymentMethod
            Delivery Method: $deliveryMethod
        """.trimIndent()

        findViewById<TextView>(R.id.deliveryMethodTextView).text = "Delivery Method: $deliveryMethod"
        findViewById<TextView>(R.id.locationTextView).text = if (deliveryMethod == "Door Delivery") {
            "Address: $street, $city, $postalCode"
        } else {
            "Pickup Location: $location"
        }

        findViewById<TextView>(R.id.orderPlacedTextView).text =
            "Your $brand $model order #$orderNumber was placed. $timestamp"

        findViewById<TextView>(R.id.processingTextView).text =
            "Your $brand $model order is being prepared right now and will soon be ready for $deliveryMethod. $timestamp"

        findViewById<Button>(R.id.returnToHomeButton).setOnClickListener {
            val mainIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(mainIntent)
            finish()
        }
    }

    private fun generateOrderNumber(): String {
        return (10000..99999).random().toString()
    }
}