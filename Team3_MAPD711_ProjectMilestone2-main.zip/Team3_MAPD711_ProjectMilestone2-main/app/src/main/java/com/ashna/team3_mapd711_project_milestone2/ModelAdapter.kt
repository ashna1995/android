package com.ashna.team3_mapd711_project_milestone2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ModelAdapter(
    private val models: List<Model>,
    private val onModelSelected: (Model) -> Unit
) : RecyclerView.Adapter<ModelAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val modelName: TextView = view.findViewById(R.id.modelNameTextView)
        val modelImage: ImageView = view.findViewById(R.id.modelImageView)
        val modelPrice: TextView = view.findViewById(R.id.modelPriceTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_model, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = models[position]
        holder.modelName.text = model.name
        holder.modelImage.setImageResource(model.imageResId)
        holder.modelPrice.text = "Starting at $${model.basePrice}"
        holder.itemView.setOnClickListener { onModelSelected(model) }
    }

    override fun getItemCount() = models.size
}