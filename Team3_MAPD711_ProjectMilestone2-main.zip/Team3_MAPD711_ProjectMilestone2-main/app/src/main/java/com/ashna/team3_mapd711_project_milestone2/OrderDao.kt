package com.ashna.team3_mapd711_project_milestone2

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface OrderDao {
    @Insert
    suspend fun insertOrder(order: Order): Long

    @Query("SELECT * FROM orders WHERE customer_id = :custId")
    fun getOrdersForCustomer(custId: Int): LiveData<List<Order>>

    // New methods
    @Query("SELECT * FROM orders")
    fun getAllOrders(): LiveData<List<Order>>

    @Query("UPDATE orders SET status = :newStatus WHERE orderId = :orderId")
    suspend fun updateOrderStatus(orderId: Int, newStatus: String)

    @Query("SELECT * FROM orders WHERE status = :status")
    fun getOrdersByStatus(status: String): LiveData<List<Order>>

    // This query assumes you have a relationship between Order and Phone entities
    @Transaction
    @Query("SELECT * FROM orders WHERE orderId = :orderId")
    fun getOrderWithPhoneDetails(orderId: Int): LiveData<OrderWithPhoneDetails>
}