package com.ashna.team3_mapd711_project_milestone2

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

class StorageAndColorActivity : AppCompatActivity() {
    private lateinit var viewModel: PhoneViewModel
    private lateinit var storageRadioGroup: RadioGroup
    private lateinit var colorSpinner: Spinner
    private lateinit var continueButton: Button
    private lateinit var phoneImage: ImageView
    private lateinit var modelNameText: TextView
    private lateinit var modelPriceText: TextView

    private var productId: Int = -1 // Initialize to -1 to check for invalid ID.
    private lateinit var currentPhone: Phone

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_storage_and_color)

        viewModel = ViewModelProvider(this).get(PhoneViewModel::class.java)

        productId = intent.getIntExtra("productId", -1) // Use -1 as a default value.

        if (productId == -1) { // Check for an invalid product ID.
            Toast.makeText(this, "Invalid product ID.", Toast.LENGTH_SHORT).show()
            finish()
            return // Exit activity if ID is invalid.
        }

        initializeViews()
        observePhoneData()
        setupColorSpinner()
        setupContinueButton()
    }

    private fun initializeViews() {
        phoneImage = findViewById(R.id.phoneImage)
        modelNameText = findViewById(R.id.modelNameText)
        modelPriceText = findViewById(R.id.modelPriceText)
        storageRadioGroup = findViewById(R.id.storageRadioGroup)
        colorSpinner = findViewById(R.id.colorSpinner)
        continueButton = findViewById(R.id.continueButton)
    }

    private fun observePhoneData() {
        viewModel.getPhoneById(productId).observe(this) { phone ->
            if (phone != null) {
                updatePhoneInfo(phone)
            } else {
                Toast.makeText(this, "Phone not found.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun updatePhoneInfo(phone: Phone) {
        currentPhone = phone

        title = "${phone.phoneMake} ${phone.phoneModel} - Select Storage & Color"
        modelNameText.text = "${phone.phoneMake} ${phone.phoneModel}"
        modelPriceText.text = "$${phone.price}"
        phoneImage.setImageResource(getPhoneImageResource(phone.phoneModel))

        setupStorageRadioGroup(phone.storageCapacity)
    }

    private fun setupStorageRadioGroup(availableStorages: String) {
        storageRadioGroup.removeAllViews()
        val storageOptions = availableStorages.split(",")
        storageOptions.forEachIndexed { index, option ->
            val radioButton = RadioButton(this).apply {
                text = option.trim()
                id = index
            }
            storageRadioGroup.addView(radioButton)
        }

        storageRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId != -1) { // Check if a radio button is selected.
                val selectedStorage = storageOptions[checkedId].trim()
                modelPriceText.text = "$${calculatePrice(selectedStorage)}"
            }
        }
    }

    private fun setupColorSpinner() {
        val colors = arrayOf("Blue", "Black", "Silver", "White")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, colors).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        colorSpinner.adapter = adapter
    }

    private fun setupContinueButton() {
        continueButton.setOnClickListener {
            if (storageRadioGroup.checkedRadioButtonId == -1) { // Check if no option is selected.
                Toast.makeText(this, "Please select a storage option.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedStorageIndex = storageRadioGroup.checkedRadioButtonId
            val selectedStorageOption =
                (storageRadioGroup.getChildAt(selectedStorageIndex) as RadioButton).text.toString()

            val selectedColor = colorSpinner.selectedItem.toString()
            val finalPrice = calculatePrice(selectedStorageOption)

            Intent(this@StorageAndColorActivity, CheckoutActivity::class.java).apply {
                putExtra("productId", productId)
                putExtra("brand", currentPhone.phoneMake)
                putExtra("model", currentPhone.phoneModel)
                putExtra("price", finalPrice)
                putExtra("storage", selectedStorageOption)
                putExtra("color", selectedColor)
                putExtra("imageResId", getPhoneImageResource(currentPhone.phoneModel)) // Pass image resource ID
            }.also { startActivity(it) }
        }
    }

    private fun calculatePrice(storage: String): Double {
        return currentPhone.price + when (storage) {
            // Adjust prices based on selected storage options.
            // Ensure these match your business logic.
            "128 GB" ->100.0
            "256 GB" ->200.0
            else ->0.0
        }
    }

    private fun getPhoneImageResource(model: String): Int {
        return when (model.toLowerCase()) {
            "iphone 14" -> R.drawable.iphone13
            "iphone 15" -> R.drawable.iphone15
            "iphone 15 pro" -> R.drawable.iphone_15_pro
            "iphone 15 pro max" -> R.drawable.iphone15pro
            "galaxy s23" -> R.drawable.samsung_s22
            "galaxy s23+" -> R.drawable.galaxys23
            "galaxy z flip 5" -> R.drawable.galaxyzfold5
            "galaxy z fold 5" -> R.drawable.galaxys21
            "pixel 8" -> R.drawable.googlepixel8
            "pixel 8 pro" -> R.drawable.googlepixel8pro
            "pixel 7a" -> R.drawable.google
            "pixel fold" -> R.drawable.googlepixel9
            else -> R.drawable.cenphone_logo // Default image if model is not recognized
        }
    }
}