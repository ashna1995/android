package com.ashna.team3_mapd711_project_milestone2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


/***
CenPhone Mobile Shopping App
 *
 * By Team 3
 * Ashna Paul (301479554)
 * Aarya Savaliya (301473601)
 * Aditya Janjanam (301357523)
 *
 * Course Name: Samsung Android Application Development
 * Course Code: MAPD 711
 *
 * ***/


class CustomerInfoActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private lateinit var fullNameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var addressTextView: TextView
    private lateinit var cityTextView: TextView
    private lateinit var postalCodeTextView: TextView
    private lateinit var countryTextView: TextView
    private lateinit var provinceTextView: TextView
    private lateinit var editButton: Button
    private lateinit var proceedToPaymentButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer_info)

        // Pass lifecycleScope to getDatabase
        db = AppDatabase.getDatabase(this, lifecycleScope)
        initializeViews()
        loadCustomerData()

        editButton.setOnClickListener {
            val intent = Intent(this, UpdateCustomerActivity::class.java)
            startActivity(intent)
        }

        proceedToPaymentButton.setOnClickListener {
            val intent = Intent(this, PaymentConfirmationActivity::class.java)
            startActivity(intent)
        }
    }

    private fun initializeViews() {
        fullNameTextView = findViewById(R.id.fullNameTextView)
        emailTextView = findViewById(R.id.emailTextView)
        addressTextView = findViewById(R.id.addressTextView)
        cityTextView = findViewById(R.id.cityTextView)
        postalCodeTextView = findViewById(R.id.postalCodeTextView)
        countryTextView = findViewById(R.id.countryTextView)
        provinceTextView = findViewById(R.id.provinceTextView)
        editButton = findViewById(R.id.editButton)
        proceedToPaymentButton = findViewById(R.id.proceedToPaymentButton)
    }

    private fun loadCustomerData() {
        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val userName = sharedPref.getString("USER_NAME", null)

        userName?.let {
            lifecycleScope.launch(Dispatchers.IO) {
                val customer = db.customerDao().getCustomerByUsername(userName)
                withContext(Dispatchers.Main) {
                    customer?.let { populateViews(it) }
                }
            }
        }
    }

    private fun populateViews(customer: Customer) {
        fullNameTextView.text = "${customer.firstName} ${customer.lastName}"
        emailTextView.text = customer.email
        addressTextView.text = customer.address
        cityTextView.text = customer.city
        postalCodeTextView.text = customer.postalCode
        countryTextView.text = customer.country
        provinceTextView.text = customer.province
    }

    override fun onResume() {
        super.onResume()
        loadCustomerData()
    }
}