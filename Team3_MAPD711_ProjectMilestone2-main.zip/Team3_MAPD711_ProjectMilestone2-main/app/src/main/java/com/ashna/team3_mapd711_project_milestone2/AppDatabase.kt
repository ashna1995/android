package com.ashna.team3_mapd711_project_milestone2

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Customer::class, Phone::class, Order::class], version = 3)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun phoneDao(): PhoneDao
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                )
                    .addCallback(AppDatabaseCallback(scope, context))
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance
                instance
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return getDatabase(context, CoroutineScope(Dispatchers.IO)) // Default scope
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope,
        private val context: Context // Store context here
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            // Populate the database in a coroutine
            scope.launch(Dispatchers.IO) {
                populateDatabase(getDatabase(context))
            }
        }

        private suspend fun populateDatabase(database: AppDatabase) {
            val phoneDao = database.phoneDao()
            // Add sample phone data with multiple storage options for all brands
            val phones = listOf(
                Phone(1, "Apple", "iPhone 14", "Black", "128 GB, 256 GB, 512 GB", 999.99, 10),
                Phone(2, "Apple", "iPhone 15", "White", "128 GB, 256 GB", 1099.99, 8),
                Phone(3, "Apple", "iPhone 15 Pro", "Silver", "256 GB, 512 GB", 1299.99, 5),
                Phone(4, "Apple", "iPhone 15 Pro Max", "Gold", "256 GB, 512 GB", 1399.99, 3),
                Phone(5, "Samsung", "Galaxy S23", "Blue", "128 GB, 256 GB, 512 GB", 799.99, 12),
                Phone(6, "Samsung", "Galaxy S23+", "Black", "256 GB, 512 GB", 999.99, 10),
                Phone(7, "Samsung", "Galaxy Z Flip 5", "Pink", "128 GB, 256 GB", 999.99, 8),
                Phone(8, "Samsung", "Galaxy Z Fold 5", "White", "128 GB, 256 GB", 699.99, 15),
                Phone(9, "Google", "Pixel 8 ", "Black", "128 GB, 256 GB", 999.99, 7),
                Phone(10,"Google", "Pixel 8 pro ", "Silver","256 GB, 128 GB",1799.99,5),
                Phone(11,"Google", "Pixel 7a", "Silver","256 GB ,64 GB",1799.99,5),
                Phone(12,"Google", "Pixel 7a", "Silver","256 GB ,512 GB",1799.99,5)

            )
            phones.forEach { phone ->
                phoneDao.insertPhone(phone)
            }
        }
    }
}