package com.ashna.team3_mapd711_project_milestone2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CheckoutActivity : AppCompatActivity() {
    private lateinit var orderRepository: OrderRepository // Declare repository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        // Retrieve intent data
        val brand = intent.getStringExtra("brand") ?: "Unknown Brand"
        val model = intent.getStringExtra("model") ?: "Unknown Model"
        val price = intent.getDoubleExtra("price", 0.0) // Use getDoubleExtra for price
        val storage = intent.getStringExtra("storage") ?: "N/A"
        val color = intent.getStringExtra("color") ?: "N/A"
        val imageResId = intent.getIntExtra("imageResId", R.drawable.cenphone_logo) // Default image if not found
        val productId = intent.getIntExtra("productId", -1) // Get product ID from intent

        // Set up UI elements with phone details
        findViewById<TextView>(R.id.brandModelTextView).text = "$brand $model"
        findViewById<TextView>(R.id.priceTextView).text = "Price: $${price}"
        findViewById<TextView>(R.id.storageTextView).text = "Storage: $storage"
        findViewById<TextView>(R.id.colorTextView).text = "Color: $color"
        findViewById<ImageView>(R.id.phoneImageView).setImageResource(imageResId)
        findViewById<TextView>(R.id.totalPriceTextView).text = "Total Price: $${price}"

        // Initialize repository (Assuming you have a method to get OrderDao)
        orderRepository = OrderRepository(AppDatabase.getDatabase(this).orderDao())

        val proceedToCustomerInfoButton: Button = findViewById(R.id.proceedToCustomerInfoButton)
        proceedToCustomerInfoButton.setOnClickListener {
            // Create an Order object with the necessary details
            val order = Order(
                productId = productId, // Use the product ID retrieved from the previous activity
                customerId = getCurrentCustomerId(), // Get the current customer's ID from shared preferences
                totalAmount = price,
                brand = brand,
                model = model,
                storage = storage,
                color = color
            )

            // Insert order into database using a coroutine
            lifecycleScope.launch {
                val orderId = orderRepository.insertOrder(order) // Assuming insertOrder returns the inserted order ID

                // Store the order ID in SharedPreferences
                saveOrderId(orderId)

                // Proceed to Customer Info Activity after inserting the order
                val intent = Intent(this@CheckoutActivity, CustomerInfoActivity::class.java)
                startActivity(intent)
            }
        }
    }

    private fun saveOrderId(orderId: Long) {
        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putLong("ORDER_ID", orderId) // Save the order ID as a long value
            apply() // Commit changes asynchronously
        }
    }

    private fun getCurrentCustomerId(): Int {
        // Retrieve the current customer's ID from shared preferences
        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        return sharedPref.getInt("CUSTOMER_ID", -1) // Return -1 if not found, indicating an error or no user logged in.
    }
}