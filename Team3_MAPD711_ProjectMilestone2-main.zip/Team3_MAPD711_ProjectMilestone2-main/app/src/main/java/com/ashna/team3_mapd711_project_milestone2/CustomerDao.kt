package com.ashna.team3_mapd711_project_milestone2

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface CustomerDao {
    @Insert
    suspend fun insert(customer: Customer)

    @Query("SELECT * FROM customer WHERE userName = :username AND password = :password LIMIT 1")
    suspend fun login(username: String, password: String): Customer?

    @Query("SELECT * FROM customer WHERE (userName = :userNameOrEmail OR email = :userNameOrEmail) AND password = :password")
    suspend fun loginWithEmailOrUsername(userNameOrEmail: String, password: String): Customer?

    @Query("SELECT * FROM customer WHERE userName = :username LIMIT 1")
    suspend fun getCustomerByUsername(username: String): Customer?

    @Query("UPDATE customer SET password = :password, address = :address, city = :city, postalCode = :postalCode, province = :province, country = :country WHERE userName = :username")
    suspend fun updateCustomerInfoWithPassword(username: String, password: String, address: String, city: String, postalCode: String, province: String, country: String)

    @Query("UPDATE customer SET address = :address, city = :city, postalCode = :postalCode, province = :province, country = :country WHERE userName = :username")
    suspend fun updateCustomerInfoWithoutPassword(username: String, address: String, city: String, postalCode: String, province: String, country: String)

    @Query("SELECT * FROM customer WHERE custId = :customerId LIMIT 1")
    suspend fun getCustomerById(customerId: Int): Customer?

}