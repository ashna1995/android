package com.ashna.team3_mapd711_project_milestone2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/***
CenPhone Mobile Shopping App
 *
 * By Team 3
 * Ashna Paul (301479554)
 * Aarya Savaliya (301473601)
 * Aditya Janjanam (301357523)
 *
 * Course Name: Samsung Android Application Development
 * Course Code: MAPD 711
 *
 * ***/
class PaymentConfirmationActivity : AppCompatActivity() {

    private lateinit var cardNumberEditText: EditText
    private lateinit var expiryMonthSpinner: Spinner
    private lateinit var expiryYearSpinner: Spinner
    private lateinit var cvvEditText: EditText
    private lateinit var paymentMethodRadioGroup: RadioGroup
    private lateinit var confirmButton: Button
    private lateinit var cardInfoLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_confirmation)

        initializeViews()
        setupExpiryDateSpinners()
        setupPaymentMethodListener()

        confirmButton.setOnClickListener {
            if (validatePaymentFields()) {
                navigateToDeliveryOptions()
            }
        }
    }

    private fun initializeViews() {
        cardNumberEditText = findViewById(R.id.cardNumberEditText)
        expiryMonthSpinner = findViewById(R.id.expiryMonthSpinner)
        expiryYearSpinner = findViewById(R.id.expiryYearSpinner)
        cvvEditText = findViewById(R.id.cvvEditText)
        paymentMethodRadioGroup = findViewById(R.id.paymentMethodRadioGroup)
        confirmButton = findViewById(R.id.confirmButton)
        cardInfoLayout = findViewById(R.id.cardInfoLayout)
    }

    private fun setupExpiryDateSpinners() {
        val months = (1..12).map { it.toString().padStart(2, '0') }
        expiryMonthSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, months)

        val currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        val years = (currentYear..currentYear + 10).map { it.toString() }
        expiryYearSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, years)
    }

    private fun setupPaymentMethodListener() {
        paymentMethodRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            cardInfoLayout.visibility = when (checkedId) {
                R.id.creditCardRadioButton, R.id.debitCardRadioButton -> View.VISIBLE
                else -> View.GONE
            }
        }
    }

    private fun validatePaymentFields(): Boolean {
        val selectedPaymentMethod = getSelectedPaymentMethod()
        if (selectedPaymentMethod == "Credit Card" || selectedPaymentMethod == "Debit Card") {
            if (cardNumberEditText.text.isNullOrEmpty()) {
                cardNumberEditText.error = "Card number is required"
                return false
            }
            if (cvvEditText.text.isNullOrEmpty()) {
                cvvEditText.error = "CVV is required"
                return false
            }
            if (expiryMonthSpinner.selectedItem == null) {
                Toast.makeText(this, "Please select expiry month", Toast.LENGTH_SHORT).show()
                return false
            }
            if (expiryYearSpinner.selectedItem == null) {
                Toast.makeText(this, "Please select expiry year", Toast.LENGTH_SHORT).show()
                return false
            }
        } else if (selectedPaymentMethod == "Not selected") {
            Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun getSelectedPaymentMethod(): String {
        return when (paymentMethodRadioGroup.checkedRadioButtonId) {
            R.id.creditCardRadioButton -> "Credit Card"
            R.id.debitCardRadioButton -> "Debit Card"
            R.id.applePayRadioButton -> "Apple Pay"
            R.id.googlePayRadioButton -> "Google Pay"
            else -> "Not selected"
        }
    }

    private fun navigateToDeliveryOptions() {
        val deliveryIntent = Intent(this, DeliveryOptionsActivity::class.java).apply {
            putExtras(intent.extras ?: Bundle())
            putExtra("paymentMethod", getSelectedPaymentMethod())
            if (getSelectedPaymentMethod() in listOf("Credit Card", "Debit Card")) {
                putExtra("cardNumber", cardNumberEditText.text.toString())
                putExtra("expiryMonth", expiryMonthSpinner.selectedItem.toString())
                putExtra("expiryYear", expiryYearSpinner.selectedItem.toString())
                putExtra("cvv", cvvEditText.text.toString())
            }
        }
        startActivity(deliveryIntent)
    }
}