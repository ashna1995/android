package com.ashna.team3_mapd711_project_milestone2

import androidx.lifecycle.LiveData

class PhoneRepository(private val phoneDao: PhoneDao) {
    val allPhones: LiveData<List<Phone>> = phoneDao.getAllPhones()

    suspend fun insert(phone: Phone) {
        phoneDao.insertPhone(phone)
    }

    fun getPhoneById(id: Int): LiveData<Phone> {
        return phoneDao.getPhoneById(id)
    }

    // New method to get all phones of a specific brand
    fun getPhonesByBrand(brand: String): LiveData<List<Phone>> {
        return phoneDao.getPhonesByBrand(brand)
    }

    // New method to get phones within a price range
    fun getPhonesInPriceRange(minPrice: Double, maxPrice: Double): LiveData<List<Phone>> {
        return phoneDao.getPhonesInPriceRange(minPrice, maxPrice)
    }

    // New method to update phone stock
    suspend fun updatePhoneStock(productId: Int, newStock: Int) {
        phoneDao.updatePhoneStock(productId, newStock)
    }
}