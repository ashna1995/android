package com.ashna.team3_mapd711_project_milestone2

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class PhoneViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PhoneRepository
    val allPhones: LiveData<List<Phone>>

    init {
        val phoneDao = AppDatabase.getDatabase(application).phoneDao()
        repository = PhoneRepository(phoneDao)
        allPhones = repository.allPhones
    }

    fun insert(phone: Phone) = viewModelScope.launch {
        repository.insert(phone)
    }

    fun getPhoneById(id: Int): LiveData<Phone> {
        return repository.getPhoneById(id)
    }
}