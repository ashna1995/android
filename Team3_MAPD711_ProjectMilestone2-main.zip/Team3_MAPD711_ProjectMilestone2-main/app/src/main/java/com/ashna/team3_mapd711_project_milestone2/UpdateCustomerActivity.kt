package com.ashna.team3_mapd711_project_milestone2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class UpdateCustomerActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private lateinit var passwordLayout: TextInputLayout
    private lateinit var addressLayout: TextInputLayout
    private lateinit var cityLayout: TextInputLayout
    private lateinit var postalCodeLayout: TextInputLayout
    private lateinit var provinceLayout: TextInputLayout
    private lateinit var countryLayout: TextInputLayout
    private lateinit var updateButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_customer)

        db = AppDatabase.getDatabase(this)
        initializeViews()
        loadCustomerData()

        updateButton.setOnClickListener {
            if (validateInputs()) {
                updateCustomerInfo()
            }
        }
    }

    private fun initializeViews() {
        passwordLayout = findViewById(R.id.passwordLayout)
        addressLayout = findViewById(R.id.addressLayout)
        cityLayout = findViewById(R.id.cityLayout)
        postalCodeLayout = findViewById(R.id.postalCodeLayout)
        provinceLayout = findViewById(R.id.provinceLayout)
        countryLayout = findViewById(R.id.countryLayout)
        updateButton = findViewById(R.id.updateButton)
    }

    private fun loadCustomerData() {
        val sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val userName = sharedPref.getString("USER_NAME", null)

        userName?.let {
            lifecycleScope.launch(Dispatchers.IO) {
                val customer = db.customerDao().getCustomerByUsername(userName)
                withContext(Dispatchers.Main) {
                    customer?.let { populateFields(it) }
                }
            }
        }
    }

    private fun populateFields(customer: Customer) {
        addressLayout.editText?.setText(customer.address)
        cityLayout.editText?.setText(customer.city)
        postalCodeLayout.editText?.setText(customer.postalCode)
        provinceLayout.editText?.setText(customer.province)
        countryLayout.editText?.setText(customer.country)
    }

    private fun validateInputs(): Boolean {
        var isValid = true

        if (passwordLayout.editText?.text.toString().isNotEmpty() && passwordLayout.editText?.text.toString().trim().length < 6) {
            passwordLayout.error = "Password must be at least 6 characters"
            isValid = false
        } else {
            passwordLayout.error = null
        }

        if (addressLayout.editText?.text.toString().trim().isEmpty()) {
            addressLayout.error = "Address is required"
            isValid = false
        } else {
            addressLayout.error = null
        }

        if (cityLayout.editText?.text.toString().trim().isEmpty()) {
            cityLayout.error = "City is required"
            isValid = false
        } else {
            cityLayout.error = null
        }

        if (!postalCodeLayout.editText?.text.toString().trim()
                .matches(Regex("^[A-Za-z]\\d[A-Za-z]\\s\\d[A-Za-z]\\d$"))
        ) {
            postalCodeLayout.error = "Enter a valid Canadian postal code"
            isValid = false
        } else {
            postalCodeLayout.error = null
        }

        if (provinceLayout.editText?.text.toString().trim().isEmpty()) {
            provinceLayout.error = "Province is required"
            isValid = false
        } else {
            provinceLayout.error = null
        }

        if (countryLayout.editText?.text.toString().trim().isEmpty()) {
            countryLayout.error = "Country is required"
            isValid = false
        } else {
            countryLayout.error = null
        }

        return isValid
    }

    private fun updateCustomerInfo() {
        val sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val userName = sharedPref.getString("USER_NAME", null)

        userName?.let {
            val password = passwordLayout.editText?.text.toString().trim()
            val address = addressLayout.editText?.text.toString().trim()
            val city = cityLayout.editText?.text.toString().trim()
            val postalCode = postalCodeLayout.editText?.text.toString().trim()
            val province = provinceLayout.editText?.text.toString().trim()
            val country = countryLayout.editText?.text.toString().trim()

            lifecycleScope.launch(Dispatchers.IO) {
                if (password.isNotEmpty()) {
                    db.customerDao().updateCustomerInfoWithPassword(userName, password, address, city, postalCode, province, country)
                } else {
                    db.customerDao().updateCustomerInfoWithoutPassword(userName, address, city, postalCode, province, country)
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@UpdateCustomerActivity,
                        "Information updated successfully",
                        Toast.LENGTH_SHORT
                    ).show()
                    val intent = Intent(this@UpdateCustomerActivity, CustomerInfoActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    finish()
                }
            }
        }
    }
}