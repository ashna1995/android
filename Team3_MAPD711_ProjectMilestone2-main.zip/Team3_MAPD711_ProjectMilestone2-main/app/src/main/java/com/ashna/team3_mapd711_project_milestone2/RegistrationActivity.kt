package com.ashna.team3_mapd711_project_milestone2

import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RegistrationActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase

    // UI Elements
    private lateinit var userNameLayout: TextInputLayout
    private lateinit var passwordLayout: TextInputLayout
    private lateinit var emailLayout: TextInputLayout
    private lateinit var firstNameLayout: TextInputLayout
    private lateinit var lastNameLayout: TextInputLayout
    private lateinit var addressLayout: TextInputLayout
    private lateinit var cityLayout: TextInputLayout
    private lateinit var postalCodeLayout: TextInputLayout
    private lateinit var countryLayout: TextInputLayout
    private lateinit var provinceLayout: TextInputLayout
    private lateinit var registerButton: Button
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        // Initialize Room Database
        db = AppDatabase.getDatabase(this)

        // Initialize UI Elements
        initializeViews()
        setupTextChangeListeners()

        // Register Button Click Listener
        registerButton.setOnClickListener {
            if (validateInputs()) {
                registerUser()
            }
        }
    }

    private fun initializeViews() {
        userNameLayout = findViewById(R.id.userNameLayout)
        passwordLayout = findViewById(R.id.passwordLayout)
        emailLayout = findViewById(R.id.emailLayout)
        firstNameLayout = findViewById(R.id.firstNameLayout)
        lastNameLayout = findViewById(R.id.lastNameLayout)
        addressLayout = findViewById(R.id.addressLayout)
        cityLayout = findViewById(R.id.cityLayout)
        postalCodeLayout = findViewById(R.id.postalCodeLayout)
        countryLayout = findViewById(R.id.countryLayout)
        provinceLayout = findViewById(R.id.provinceLayout)
        registerButton = findViewById(R.id.registerButton)
        progressBar = findViewById(R.id.progressBar)
    }

    private fun setupTextChangeListeners() {
        userNameLayout.editText?.addTextChangedListener { userNameLayout.error = null }
        passwordLayout.editText?.addTextChangedListener { passwordLayout.error = null }
        emailLayout.editText?.addTextChangedListener { emailLayout.error = null }
        firstNameLayout.editText?.addTextChangedListener { firstNameLayout.error = null }
        lastNameLayout.editText?.addTextChangedListener { lastNameLayout.error = null }
        addressLayout.editText?.addTextChangedListener { addressLayout.error = null }
        cityLayout.editText?.addTextChangedListener { cityLayout.error = null }
        postalCodeLayout.editText?.addTextChangedListener { postalCodeLayout.error = null }
        countryLayout.editText?.addTextChangedListener { countryLayout.error = null }
        provinceLayout.editText?.addTextChangedListener { provinceLayout.error = null }
    }

    private fun validateInputs(): Boolean {
        var isValid = true

        if (userNameLayout.editText?.text.toString().trim().isEmpty()) {
            userNameLayout.error = "Username is required"
            isValid = false
        }

        if (passwordLayout.editText?.text.toString().trim().length < 6) {
            passwordLayout.error = "Password must be at least 6 characters"
            isValid = false
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(emailLayout.editText?.text.toString().trim()).matches()) {
            emailLayout.error = "Enter a valid email address"
            isValid = false
        }

        if (firstNameLayout.editText?.text.toString().trim().isEmpty()) {
            firstNameLayout.error = "First name is required"
            isValid = false
        }

        if (lastNameLayout.editText?.text.toString().trim().isEmpty()) {
            lastNameLayout.error = "Last name is required"
            isValid = false
        }

        if (addressLayout.editText?.text.toString().trim().isEmpty()) {
            addressLayout.error = "Address is required"
            isValid = false
        }

        if (cityLayout.editText?.text.toString().trim().isEmpty()) {
            cityLayout.error = "City is required"
            isValid = false
        }

        if (!postalCodeLayout.editText?.text.toString().trim().matches(Regex("^[A-Za-z]\\d[A-Za-z]\\s\\d[A-Za-z]\\d$"))) {
            postalCodeLayout.error = "Enter a valid Canadian postal code"
            isValid = false
        }

        if (countryLayout.editText?.text.toString().trim().isEmpty()) {
            countryLayout.error = "Country is required"
            isValid = false
        }

        if (provinceLayout.editText?.text.toString().trim().isEmpty()) {
            provinceLayout.error = "Province is required"
            isValid = false
        }

        return isValid
    }

    private fun registerUser() {
        // Show progress bar
        progressBar.visibility = View.VISIBLE
        registerButton.isEnabled = false

        // Capture user input from EditTexts
        val userName = userNameLayout.editText?.text.toString().trim()
        val password = passwordLayout.editText?.text.toString().trim()
        val email = emailLayout.editText?.text.toString().trim()
        val firstName = firstNameLayout.editText?.text.toString().trim()
        val lastName = lastNameLayout.editText?.text.toString().trim()
        val address = addressLayout.editText?.text.toString().trim()
        val city = cityLayout.editText?.text.toString().trim()
        val postalCode = postalCodeLayout.editText?.text.toString().trim()
        val country = countryLayout.editText?.text.toString().trim()
        val province = provinceLayout.editText?.text.toString().trim()

        // Create a new Customer object
        val newCustomer = Customer(
            userName = userName,
            password = password,
            email = email,
            firstName = firstName,
            lastName = lastName,
            address = address,
            city = city,
            postalCode = postalCode,
            country = country,
            province = province
        )

        // Insert into database using coroutines
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                db.customerDao().insert(newCustomer)
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@RegistrationActivity, "Registration Successful", Toast.LENGTH_SHORT).show()
                    finish() // Close activity after registration
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@RegistrationActivity, "Registration failed: ${e.message}", Toast.LENGTH_LONG).show()
                    progressBar.visibility = View.GONE
                    registerButton.isEnabled = true
                }
            }
        }
    }
}
