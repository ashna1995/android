package com.ashna.team3_mapd711_project_milestone2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * CenPhone Mobile Shopping App
 *
 * By Team 3
 * Ashna Paul (301479554)
 * Aarya Savaliya (301473601)
 * Aditya Janjanam (301357523)
 *
 * Course Name: Samsung Android Application Development
 * Course Code: MAPD 711
 *
 * This app allows users to browse and purchase smartphones from various brands.
 * It features a user-friendly interface for selecting phone models, storage options,
 * and colors, as well as a streamlined checkout process.
 */


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val orderButton = findViewById<Button>(R.id.orderButton)
        orderButton.setOnClickListener {
            Toast.makeText(this, "Button Clicked", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        }

        // Add a button for login
        val loginButton = findViewById<Button>(R.id.loginButton)
        loginButton.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}