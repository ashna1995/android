package com.ashna.team3_mapd711_project_milestone2

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ModelSelectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_model_selection)

        val brand = intent.getStringExtra("brand") ?: return // Handle null case appropriately.
        title = "$brand Models"

        val brandLogo: ImageView = findViewById(R.id.brandLogo)
        brandLogo.setImageResource(getBrandLogoResId(brand))

        val headerText: TextView = findViewById(R.id.headerText)
        headerText.text = "Select Your $brand Model"

        val models = getModelsForBrand(brand)

        val recyclerView = findViewById<RecyclerView>(R.id.modelRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = ModelAdapter(models) { model ->
            openStorageAndColorSelection(model)
        }
    }

    private fun getBrandLogoResId(brand: String): Int {
        return when (brand) {
            "iPhone" -> R.drawable.apple
            "Samsung" -> R.drawable.sumsung
            "Google Pixel" -> R.drawable.pixel
            else -> R.drawable.cenphone_logo // Default logo if brand is not recognized.
        }
    }

    private fun getModelsForBrand(brand: String): List<Model> {
        return when (brand) {
            "iPhone" -> listOf(
                Model(1,"iPhone 14" ,999 ,R.drawable.iphone13),
                Model(2,"iPhone 15" ,1099 ,R.drawable.iphone15),
                Model(3,"iPhone 15 Pro" ,1299 ,R.drawable.iphone_15_pro),
                Model(4,"iPhone 15 Pro Max" ,1399 ,R.drawable.iphone15pro)
            )
            "Samsung" -> listOf(
                Model(5,"Galaxy S23" ,799 ,R.drawable.samsung_s22),
                Model(6,"Galaxy S23+" ,999 ,R.drawable.galaxys23),
                Model(7,"Galaxy Z Flip 5" ,999 ,R.drawable.galaxyzfold5),
                Model(8,"Galaxy Z Fold 5" ,1799 ,R.drawable.galaxys21)
            )
            "Google Pixel" -> listOf(
                Model(9,"Pixel 8" ,699 ,R.drawable.googlepixel8),
                Model(10,"Pixel 8 Pro" ,999 ,R.drawable.googlepixel8pro),
                Model(11,"Pixel 7a" ,499 ,R.drawable.google),
                Model(12,"Pixel Fold" ,1799 ,R.drawable.googlepixel9)
            )
            else -> emptyList()
        }
    }

    private fun openStorageAndColorSelection(model: Model) {
        val intent = Intent(this, StorageAndColorActivity::class.java).apply {
            putExtra("productId", model.productId)
            putExtra("brand", model.name)
            putExtra("model", model.name)
            putExtra("basePrice", model.basePrice)
            putExtra("imageResId", model.imageResId)
        }
        startActivity(intent)
    }
}

data class Model(val productId: Int, val name: String, val basePrice: Int, val imageResId: Int)