package com.ashna.team3_mapd711_project_milestone2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/***
CenPhone Mobile Shopping App
 *
 * By Team 3
 * Ashna Paul (301479554)
 * Aarya Savaliya (301473601)
 * Aditya Janjanam (301357523)
 *
 * Course Name: Samsung Android Application Development
 * Course Code: MAPD 711
 *
 * ***/
data class PhoneBrand(val name: String, val logoResId: Int)

class PhoneBrandAdapter(
    private val brands: List<PhoneBrand>,
    private val onClick: (PhoneBrand) -> Unit
) : RecyclerView.Adapter<PhoneBrandAdapter.PhoneBrandViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhoneBrandViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_phone_brand, parent, false)
        return PhoneBrandViewHolder(view)
    }

    override fun onBindViewHolder(holder: PhoneBrandViewHolder, position: Int) {
        holder.bind(brands[position], onClick)
    }

    override fun getItemCount() = brands.size

    class PhoneBrandViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val brandName: TextView = itemView.findViewById(R.id.brand_name)
        private val brandLogo: ImageView = itemView.findViewById(R.id.brand_logo)

        fun bind(brand: PhoneBrand, onClick: (PhoneBrand) -> Unit) {
            brandName.text = brand.name
            brandLogo.setImageResource(brand.logoResId)
            itemView.setOnClickListener { onClick(brand) }
        }
    }

}
