package com.ashna.team3_mapd711_project_milestone2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
/***
CenPhone Mobile Shopping App
 *
 * By Team 3
 * Ashna Paul (301479554)
 * Aarya Savaliya (301473601)
 * Aditya Janjanam (301357523)
 *
 * Course Name: Samsung Android Application Development
 * Course Code: MAPD 711
 *
 * ***/
class DeliveryOptionsActivity : AppCompatActivity() {
    private lateinit var deliveryMethodRadioGroup: RadioGroup
    private lateinit var locationSpinner: Spinner
    private lateinit var continueButton: Button
    private lateinit var locationLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delivery_options)

        initializeViews()
        setupDeliveryMethodRadioGroup()
        setupLocationSpinner()
        setupContinueButton()
    }

    private fun initializeViews() {
        deliveryMethodRadioGroup = findViewById(R.id.deliveryMethodRadioGroup)
        locationSpinner = findViewById(R.id.locationSpinner)
        continueButton = findViewById(R.id.continueButton)
        locationLayout = findViewById(R.id.locationLayout)
    }

    private fun setupDeliveryMethodRadioGroup() {
        val methods = listOf("Door Delivery", "Pick-up")
        methods.forEachIndexed { index, method ->
            val radioButton = RadioButton(this)
            radioButton.id = View.generateViewId()
            radioButton.text = method
            radioButton.setTextColor(ContextCompat.getColor(this, R.color.primaryText))
            radioButton.setBackgroundResource(R.drawable.radio_button_background)
            radioButton.buttonDrawable = null
            radioButton.setPadding(
                resources.getDimensionPixelSize(R.dimen.padding_medium),
                resources.getDimensionPixelSize(R.dimen.padding_medium),
                resources.getDimensionPixelSize(R.dimen.padding_medium),
                resources.getDimensionPixelSize(R.dimen.padding_medium)
            )
            val params = RadioGroup.LayoutParams(
                RadioGroup.LayoutParams.MATCH_PARENT,
                RadioGroup.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, if (index == 0) 0 else resources.getDimensionPixelSize(R.dimen.margin_small), 0, 0)
            deliveryMethodRadioGroup.addView(radioButton, params)
        }

        deliveryMethodRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            val selectedRadioButton = findViewById<RadioButton>(checkedId)
            locationLayout.visibility = if (selectedRadioButton.text == "Pick-up") View.VISIBLE else View.GONE
        }
    }

    private fun setupLocationSpinner() {
        val locations = arrayOf("Morningside", "Downsview", "Ashtonbee", "Progress", "SAC")
        val adapter = ArrayAdapter(this, R.layout.spinner_item, locations)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        locationSpinner.adapter = adapter
    }

    private fun setupContinueButton() {
        continueButton.setOnClickListener {
            val selectedMethodId = deliveryMethodRadioGroup.checkedRadioButtonId
            if (selectedMethodId == -1) {
                Toast.makeText(this, "Please select a delivery method", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedMethod = findViewById<RadioButton>(selectedMethodId).text.toString()
            val selectedLocation = if (selectedMethod == "Pick-up") locationSpinner.selectedItem.toString() else ""

            if (selectedMethod == "Door Delivery") {
                navigateToOrderConfirmation(selectedMethod, "")
            } else {
                navigateToLocationMap(selectedMethod, selectedLocation)
            }
        }
    }

    private fun navigateToLocationMap(deliveryMethod: String, location: String) {
        val intent = Intent(this, LocationMapActivity::class.java).apply {
            putExtra("deliveryMethod", deliveryMethod)
            putExtra("location", location)
            putExtras(this@DeliveryOptionsActivity.intent)
        }
        startActivity(intent)
    }

    private fun navigateToOrderConfirmation(deliveryMethod: String, location: String) {
        val intent = Intent(this, OrderConfirmationActivity::class.java).apply {
            putExtra("deliveryMethod", deliveryMethod)
            putExtra("location", location)
            putExtras(this@DeliveryOptionsActivity.intent)
        }
        startActivity(intent)
    }
}