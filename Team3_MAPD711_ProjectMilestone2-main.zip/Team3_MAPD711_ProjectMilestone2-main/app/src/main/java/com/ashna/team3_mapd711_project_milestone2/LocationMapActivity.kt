// LocationMapActivity.kt
package com.ashna.team3_mapd711_project_milestone2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class LocationMapActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var mMap: GoogleMap
    private lateinit var location: String
    private lateinit var confirmButton: Button
    private lateinit var mapTypeRadioGroup: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_map)

        location = intent.getStringExtra("location") ?: "Unknown Location"
        title = "$location - Map View"

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        confirmButton = findViewById(R.id.confirmButton)
        confirmButton.setOnClickListener {
            navigateToOrderConfirmation()
        }

        mapTypeRadioGroup = findViewById(R.id.mapTypeRadioGroup)
        mapTypeRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.radioNormal -> mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
                R.id.radioSatellite -> mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
                R.id.radioHybrid -> mMap.mapType = GoogleMap.MAP_TYPE_HYBRID
                R.id.radioTerrain -> mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val locationCoordinates = getLocationCoordinates(location)
        val markerOptions = MarkerOptions().position(locationCoordinates).title(location)
        mMap.addMarker(markerOptions)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(locationCoordinates, 15f))

        val snippet = getLocationDetails(location)
        mMap.setInfoWindowAdapter(CustomInfoWindowAdapter(this, snippet))

        // Enable zoom controls
        mMap.uiSettings.isZoomControlsEnabled = true
    }

    private fun getLocationCoordinates(location: String): LatLng {
        return when (location) {
            "Morningside" -> LatLng(43.7854, -79.2265)
            "Downsview" -> LatLng(43.7505, -79.4702)
            "Ashtonbee" -> LatLng(43.7304, -79.2973)
            "Progress" -> LatLng(43.7849, -79.2269)
            "SAC" -> LatLng(43.6858, -79.3414)
            else -> LatLng(43.7854, -79.2265) // Default to Morningside
        }
    }

    private fun getLocationDetails(location: String): String {
        return when (location) {
            "Morningside" -> "Address: 755 Morningside Ave, Scarborough, ON M1C 4Z4\nPhone: (416) 289-5000\nWebsite: centennialcollege.ca\nHours: Mon-Fri 8:30 AM - 4:30 PM"
            "Downsview" -> "Address: 65 Carl Hall Rd, North York, ON M3K 2E1\nPhone: (416) 289-5000\nWebsite: centennialcollege.ca\nHours: Mon-Fri 8:30 AM - 4:30 PM"
            "Ashtonbee" -> "Address: 75 Ashtonbee Rd, Scarborough, ON M1L 4C9\nPhone: (416) 289-5000\nWebsite: centennialcollege.ca\nHours: Mon-Fri 8:30 AM - 4:30 PM"
            "Progress" -> "Address: 941 Progress Ave, Scarborough, ON M1G 3T8\nPhone: (416) 289-5000\nWebsite: centennialcollege.ca\nHours: Mon-Fri 8:30 AM - 4:30 PM"
            "SAC" -> "Address: 937 Progress Ave, Scarborough, ON M1G 3T8\nPhone: (416) 289-5000\nWebsite: centennialcollege.ca\nHours: Mon-Fri 8:30 AM - 4:30 PM"
            else -> "Location details not available"
        }
    }

    private fun navigateToOrderConfirmation() {
        val intent = Intent(this, OrderConfirmationActivity::class.java).apply {
            putExtras(this@LocationMapActivity.intent)
        }
        startActivity(intent)
        finish()
    }
}