package com.ashna.team3_mapd711_project_milestone2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
/***
CenPhone Mobile Shopping App
 *
 * By Team 3
 * Ashna Paul (301479554)
 * Aarya Savaliya (301473601)
 * Aditya Janjanam (301357523)
 *
 * Course Name: Samsung Android Application Development
 * Course Code: MAPD 711
 *
 * ***/
class PhoneBrandActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone_brand)

        val welcomeTextView: TextView = findViewById(R.id.welcomeTextView)
        val userName = getUserNameFromSharedPreferences()
        welcomeTextView.text = "Welcome, $userName!"

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        // Set up RecyclerView for brands
        val brandRecyclerView: RecyclerView = findViewById(R.id.brand_recycler_view)
        brandRecyclerView.layoutManager = LinearLayoutManager(this)

        // List of phone brands
        val phoneBrands = listOf(
            PhoneBrand("iPhone", R.drawable.apple),
            PhoneBrand("Samsung", R.drawable.sumsung),
            PhoneBrand("Google Pixel", R.drawable.pixel)
        )

        // Set adapter
        brandRecyclerView.adapter = PhoneBrandAdapter(phoneBrands) { brand ->
            openModelSelection(brand.name)
        }
    }
    private fun getUserNameFromSharedPreferences(): String {
        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        return sharedPref.getString("USER_NAME", "Guest") ?: "Guest"
    }

    private fun openModelSelection(brand: String) {
        val intent = Intent(this, ModelSelectionActivity::class.java)
        intent.putExtra("brand", brand)
        startActivity(intent)
    }

    private fun getUserEmailFromSharedPreferences(): String? {
        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        return sharedPref.getString("USER_EMAIL", null)
    }
}
