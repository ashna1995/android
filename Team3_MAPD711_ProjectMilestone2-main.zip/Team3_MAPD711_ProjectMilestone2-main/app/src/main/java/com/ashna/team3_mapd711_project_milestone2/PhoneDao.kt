package com.ashna.team3_mapd711_project_milestone2

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface PhoneDao {
    @Query("SELECT * FROM phones")
    fun getAllPhones(): LiveData<List<Phone>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhone(phone: Phone)

    @Query("SELECT * FROM phones WHERE productId = :id")
    fun getPhoneById(id: Int): LiveData<Phone>

    @Query("SELECT * FROM phones WHERE brand = :brand")
    fun getPhonesByBrand(brand: String): LiveData<List<Phone>>

    @Query("SELECT * FROM phones WHERE price BETWEEN :minPrice AND :maxPrice")
    fun getPhonesInPriceRange(minPrice: Double, maxPrice: Double): LiveData<List<Phone>>

    @Query("UPDATE phones SET stock = :newStock WHERE productId = :productId")
    suspend fun updatePhoneStock(productId: Int, newStock: Int)
}