package com.ashna.team3_mapd711_project_milestone2

import androidx.lifecycle.LiveData
import androidx.room.Embedded
import androidx.room.Relation

class OrderRepository(private val orderDao: OrderDao) {
    suspend fun insertOrder(order: Order): Long {
        return orderDao.insertOrder(order)
    }

    fun getOrdersForCustomer(customerId: Int): LiveData<List<Order>> {
        return orderDao.getOrdersForCustomer(customerId)
    }

    // New method to get all orders
    fun getAllOrders(): LiveData<List<Order>> {
        return orderDao.getAllOrders()
    }

    // New method to update order status
    suspend fun updateOrderStatus(orderId: Int, newStatus: String) {
        orderDao.updateOrderStatus(orderId, newStatus)
    }

    // New method to get orders by status
    fun getOrdersByStatus(status: String): LiveData<List<Order>> {
        return orderDao.getOrdersByStatus(status)
    }

    // New method to get order details including phone information
    fun getOrderWithPhoneDetails(orderId: Int): LiveData<OrderWithPhoneDetails> {
        return orderDao.getOrderWithPhoneDetails(orderId)
    }
}


data class OrderWithPhoneDetails(
    @Embedded val order: Order,
    @Relation(
        parentColumn = "product_id",
        entityColumn = "productId"
    )
    val phone: Phone
)