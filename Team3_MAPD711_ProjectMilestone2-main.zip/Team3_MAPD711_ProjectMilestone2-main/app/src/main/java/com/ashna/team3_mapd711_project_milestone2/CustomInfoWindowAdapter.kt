// CustomInfoWindowAdapter.kt
package com.ashna.team3_mapd711_project_milestone2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.Marker

/***
CenPhone Mobile Shopping App
 *
 * By Team 3
 * Ashna Paul (301479554)
 * Aarya Savaliya (301473601)
 * Aditya Janjanam (301357523)
 *
 * Course Name: Samsung Android Application Development
 * Course Code: MAPD 711
 *
 * ***/
class CustomInfoWindowAdapter(private val context: Context, private val snippet: String) : GoogleMap.InfoWindowAdapter {
    override fun getInfoWindow(marker: Marker): View? {
        return null
    }

    override fun getInfoContents(marker: Marker): View {
        val view = LayoutInflater.from(context).inflate(R.layout.custom_info_window, null)
        val title = view.findViewById<TextView>(R.id.title)
        val details = view.findViewById<TextView>(R.id.details)

        title.text = marker.title
        details.text = snippet

        return view
    }
}